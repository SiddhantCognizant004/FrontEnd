import { inject } from '@angular/core';
import { Router, CanActivateFn } from '@angular/router';
import { AuthService } from '../services/auth-service';

export const guestGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (authService.isLoggedIn()) {
    const role = authService.loggedInUser()?.role;
    const routes: Record<string, string> = {
      FARMER: '/dashboard/farmer/home',
      OFFICER: '/dashboard/officer/home',
      MANAGER: '/dashboard/manager/home',
      ADMIN: '/dashboard/admin/home',
      AUDITOR: '/dashboard/auditor/home',
      TRADER: '/dashboard/trader',
      COMPLIANCE: '/dashboard/trader'
    };
    router.navigate([routes[role ?? ''] ?? '/dashboard']);
    return false;
  }

  return true;
};
